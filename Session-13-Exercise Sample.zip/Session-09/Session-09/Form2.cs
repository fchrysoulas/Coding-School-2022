﻿using Session_09.Impl;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Session_09 {
    public partial class Form2 : Form {

        private Transaction trans;
        private TransactionPolicy hal9k = new TransactionPolicy();

        public Form2() {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) {

            SecurityPolicy sp = new SecurityPolicy();

            Credentials cred = new Credentials(textBox1.Text, textBox2.Text); 

            if (sp.Auth(cred)) {

                // CONTINUE
            }
            else { 
                // VRE PIOS EISAI ESY ?

                // EXIT
            }
        }

        
        private void Form2_Load(object sender, EventArgs e) {


            trans = new Transaction() {

                ID = new Guid(),
                CustomerID = new Guid(),
                EmployeeID = new Guid(),

            };


            

            TransactionLine transLine1 = new TransactionLine() {
                ID = new Guid(),
                ProductID = new Guid(),
                Qty = 1, 
                TotalPrice = 2,
                TransactionID = trans.ID
            };


            TransactionLine transLine2 = new TransactionLine() {
                ID = new Guid(),
                ProductID = new Guid(),
                Qty = 3,
                TotalPrice = 3,
                TransactionID = trans.ID
            };

            hal9k.AddTransLine(trans, transLine1);
            hal9k.AddTransLine(trans, transLine2);


        }

        private void button2_Click(object sender, EventArgs e) {

            hal9k.CalcTotal(trans);


            textBox3.Text = trans.TotalPrice.ToString();

        }
    }
}
