using Session_09.Impl.DI;

namespace Session_09 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) {
            Run run = new Run();  
            //run.
        }

        private void Form1_Load(object sender, EventArgs e) {


            Button button = new Button() {
                Location = new System.Drawing.Point(447, 172),
                Name = "button1",
                Size = new System.Drawing.Size(75, 23),
                TabIndex = 0,
                Text = "button1",
                UseVisualStyleBackColor = true
            };

            this.Controls.Add(button);


        }
    }
}